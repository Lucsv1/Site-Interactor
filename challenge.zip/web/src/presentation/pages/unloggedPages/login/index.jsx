import { useNavigate } from "react-router-dom";
import "./style.css";
export const Login = () => {

  const navigate = useNavigate()
  const handleSubmit = (e) => {
    e.preventDefault()
    if(e.target[0].value !== "empresa@interactor.com" && e.target[0].value !== "aluno@interactor.com") return alert("Email/senha invalido")
    if(e.target[1].value !== "1234567") return alert("Email/senha invalido")
    if(e.target[0].value === "aluno@interactor.com") return navigate('/portal/dashboard')
    if(e.target[0].value === "empresa@interactor.com") return navigate('/company/dashboard')
  }

  return (
    <div className="login">
      <div className="container">
        <div className="card">
          <h1>login</h1>
          <form onSubmit={(e) => handleSubmit(e)}>
            <input type="text" placeholder="digite seu email"></input>
            <input type="password" placeholder="digite sua senha"></input>
            <button type="submit">entrar</button>
          </form>
          <br/>
          <br/>
          <br/> 
          <h4 className="fadeIn">os logins são:</h4>
          <h4 className="fadeIn">Empresa: empresa@interactor.com Senha: 1234567</h4>
          <h4 className="fadeIn">Aluno: aluno@interactor.com Senha: 1234567</h4> 
        </div>
      </div>
    </div>
  );
};
