import "./style.css";
export const DarkCard = (props) => {
  return <div className="darkcard2">{props.children}</div>;
};
