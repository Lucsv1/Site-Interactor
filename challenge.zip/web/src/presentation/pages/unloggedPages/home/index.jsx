import "./style.css";
import headerImage from "../../../../images/header-img.png";
import burocraciaImage from "../../../../images/burocracia.png";
import fiapImage from "../../../../images/fiap.png";
import aluraImage from "../../../../images/alura.png";
import ibmImage from "../../../../images/ibm.png";
import burocraciaIcon from "../../../../images/icons/burocracia.png";
import atualizadoIcon from "../../../../images/icons/atualizado.png";
import pastaIcon from "../../../../images/icons/pasta.png";
import tempoIcon from "../../../../images/icons/tempo.png";
import { Card } from "./components/card";
import { DarkCard } from "./components/darkcard";
import { IconUser } from "@tabler/icons";
import { Link } from "react-router-dom";
export const Home = () => {
  return (
    <div className="home">
      <div className="topbar">
        <nav>
          <div className="company">
            <h1>
              <span>IN</span>teractor
            </h1>
          </div>
          <ul>
            <li>
              <Link to={"/login"}>
                <span>
                  <IconUser />
                </span>
              </Link>
            </li>
            <Link to={"/register"}>
              <li>cadastre-se</li>
            </Link>
            <li>sobre nós [Em construção]</li>
          </ul>
        </nav>
      </div>

      <header>
        <div className="header-image">
          <img src={headerImage} alt="header"></img>
        </div>
        <div className="header-text">
          <h2>permita a empresa dos seus sonhos te conhecer</h2>
          <div className="container-card">
            <Card>
              <img src={burocraciaIcon} alt="icon"></img>
            </Card>
            <Card>
              <img src={atualizadoIcon} alt="icon"></img>
            </Card>
          </div>
          <div className="container-card2">
            <Card>
              <img src={pastaIcon} alt="icon"></img>
            </Card>
            <Card>
              <img src={tempoIcon} alt="icon"></img>
            </Card>
          </div>
        </div>
      </header>
      <br />
      <div className="body">
        <div className="empresas">
          <div className="empresas-text">
            <h2>Empresas parceiras</h2>
          </div>
          <div className="empresas-card">
            <DarkCard>
              <img src={aluraImage} className="img2" alt="empresa"></img>
            </DarkCard>
            <DarkCard>
              <img src={ibmImage} className="img3" alt="empresa"></img>
            </DarkCard>
            <DarkCard>
              <img src={fiapImage} className="img1" alt="empresa"></img>
            </DarkCard>
          </div>
        </div>
        <div className="burocracia">
          <h3>
            Aqui iremos te poupar de toda burocracia que ficou pro passado
            <span>
              Nós sabemos a frustração que é ficar enviando currículo para tudo
              que é empresa e a repetição de cadastro incessante. Em nosso
              sistema iremos poupa-lo de toda burocracia e criaremos o contato
              direto entre você e a empresa dos seus sonhos
            </span>
          </h3>
          <img src={burocraciaImage} alt="burocracia"></img>
        </div>
      </div>
      <div className="footer">
        <div className="text">
          <h4>
            <span>IN</span>teractor
          </h4>
          <p>Todos os direitos reservados</p>
        </div>
      </div>
    </div>
  );
};
