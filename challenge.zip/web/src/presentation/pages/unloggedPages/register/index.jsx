import { useNavigate } from "react-router-dom";
import "./style.css";
export const Register = () => {
  const navigate = useNavigate();
  const handleSubmit = (e) => {
    e.preventDefault();
    alert(
      "Cadastro esta desabilitado, estamos em construção. Utilize os logins pre-cadastrados"
    );
    setTimeout(() => {
      navigate("/login");
    }, 300);
  };

  return (
    <div className="register">
      <div className="container">
        <div className="card">
          <h1>registro - candidato</h1>
          <form onSubmit={(e) => handleSubmit(e)}>
            <input type="text" placeholder="digite seu nome"></input>
            <input type="text" placeholder="digite seu apelido"></input>
            <input type="text" placeholder="digite seu email"></input>
            <input type="password" placeholder="digite sua senha"></input>
            <button type="submit">cadastrar</button>
          </form>
          <br />
          <br />
          <br />
        </div>
      </div>
      <div className="container">
        <div className="card">
          <h1>registro - empresa</h1>
          <form onSubmit={(e) => handleSubmit(e)}>
            <input type="text" placeholder="digite o nome da empresa"></input>
            <input type="text" placeholder="digite o cnpj"></input>
            <input type="text" placeholder="digite seu email"></input>
            <input type="password" placeholder="digite sua senha"></input>
            <button type="submit">cadastrar</button>
          </form>
          <br />
          <br />
          <br />
        </div>
      </div>
    </div>
  );
};
