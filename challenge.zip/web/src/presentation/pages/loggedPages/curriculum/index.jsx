import "./style.css";
import { Link } from "react-router-dom";
import { DarkCard, Button, Input, Select, TextArea } from "./components";
import estagiarioImage from "../../../../images/estagiario.jpg";
import { useState } from "react";
export const Curriculo = () => {
  const [softSkill, setSoftSkill] = useState([]);
  const [about, setAbout] = useState();
  const [experience, setExperience] = useState([]);
  const [certificate, setCertificate] = useState([]);
  const [language, setLanguage] = useState([]);

  const handleSubmit = (e, type) => {
    e.preventDefault();

    switch (type) {
      case "softSkill":
        console.log("teste");
        let softSkillObject = {
          softSkill: e.target[0].value,
        };
        return setSoftSkill([...softSkill, softSkillObject]);
      case "language":
        let languageObject = {
          language: e.target[0].value,
          level: e.target[1].value,
        };
        return setLanguage([...language, languageObject]);

      case "about":
        return setAbout(e.target[0].value);
      case "profissionalExperience":
        let profissionalExperienceObject = {
          where: e.target[0].value,
          time: e.target[1].value,
          role: e.target[2].value,
        };
        return setExperience([...experience, profissionalExperienceObject]);
      case "certificate":
        let certificateObject = {
          name: e.target[0].value,
          time: e.target[1].value,
          where: e.target[2].value,
        };

        return setCertificate([...certificate, certificateObject]);
      default:
    }
  };
  return (
    <div className="curriculo">
      <div className="topbar white">
        <nav>
          <div className="company">
            <h1>
              <span>IN</span>teractor
            </h1>
          </div>
          <ul>
            <li>
              <Link
                to={"/portal/curriculo"}
                style={{ color: "inherit", textDecoration: "inherit" }}
              >
                Gerar curriculo
              </Link>
            </li>
            <li>
              <Link
                to={"/portal/dashboard"}
                style={{ color: "inherit", textDecoration: "inherit" }}
              >
                Dashboard
              </Link>
            </li>
          </ul>
        </nav>
      </div>
      <div className="container-curriculum">
        <div className="input">
          <DarkCard>
            <h1>Conte sobre voce</h1>
            <form onSubmit={(e) => handleSubmit(e, "about")}>
              <TextArea placeholder="Um pouco sobre voce"></TextArea>
              <Button>Adicionar</Button>
            </form>
          </DarkCard>
          <DarkCard>
            <h1>Linguas</h1>
            <form onSubmit={(e) => handleSubmit(e, "language")}>
              <Input type="text" placeholder="Idioma"></Input>
              <Select>
                <option value="básico">Basico</option>
                <option value="intermediário">Intermediario</option>
                <option value="avançado">Avançado</option>
                <option value="fluente">Fluente</option>
              </Select>
              <Button>Adicionar</Button>
            </form>
          </DarkCard>
          <DarkCard>
            <h1>Softskills</h1>
            <form id="softSkill" onSubmit={(e) => handleSubmit(e, "softSkill")}>
              <TextArea placeholder="Suas habilidades"></TextArea>
              <Button>Adicionar</Button>
            </form>
          </DarkCard>

          <DarkCard>
            <h1>Experiencia profissional</h1>
            <form onSubmit={(e) => handleSubmit(e, "profissionalExperience")}>
              <Input type="text" placeholder="Onde trabalhou"></Input>
              <Input type="text" placeholder="Quantos meses"></Input>
              <Input type="text" placeholder="Cargo"></Input>
              <Button>Adicionar</Button>
            </form>
          </DarkCard>
          <DarkCard>
            <h1>Certificados</h1>
            <form onSubmit={(e) => handleSubmit(e, "certificate")}>
              <Input type="text" placeholder="Nome do certificado"></Input>
              <Input type="text" placeholder="Tempo"></Input>
              <Input type="text" placeholder="Onde"></Input>
              <Button>Adicionar</Button>
            </form>
          </DarkCard>
        </div>
        <div className="preview-curriculum">
          <img src={estagiarioImage} alt="avatar"></img>
          <h3>Lucas Sartori</h3>
          <div className="data">
            <h4>Sobre mim</h4>
            <p>{about}</p>
            <h4>Softskills</h4>
            {softSkill.map((object) => (
              <p key={object.softSkill + Math.random()}>{object.softSkill}</p>
            ))}
            <h4>Experiência</h4>
            {experience.map((object) => (
              <p key={object.where + Math.random()}>
                {object.where} - {object.time} - {object.role}
              </p>
            ))}
            <h4>Certificados</h4>
            {certificate.map((object) => (
              <p key={object.name + Math.random()}>
                {object.name} - {object.time} - {object.where}
              </p>
            ))}
            <h4>Idiomas</h4>
            {language.map((object) => (
              <p key={object.language + Math.random()}>
                {object.language} - {object.level}
              </p>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
