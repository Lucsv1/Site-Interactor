import './style.css'
export const Button = (props) => {
    return(
        <button>{props.children}</button>
    )
}