import './style.css'
export const TextArea = (props) => {
    return(
        <textarea placeholder={props.placeholder}></textarea>
    )
}