import './style.css'
export const Select = (props) => {
    return(
        <select placeholder={props.placeholder}>{props.children}</select>
    )
}