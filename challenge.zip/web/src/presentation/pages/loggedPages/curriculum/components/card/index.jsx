import "./style.css";
export const DarkCard = (props) => {
  return (
    <div className="CurriculumCard">
      <div className="title">{props.title}</div>
      <div className="text">{props.children}</div>
    </div>
  );
};
