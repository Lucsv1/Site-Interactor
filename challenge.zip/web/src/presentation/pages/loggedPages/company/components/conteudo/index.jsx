import { Candidatos } from './candidatos'
import { Vagas } from './criarVagas'
import './index.css'
export const Conteudo = () =>{

    return(
        <div className="base_conteudo">
            <div className="conteudo">
                <Vagas/>
                <Candidatos/>
            </div>
        </div>
    )
}