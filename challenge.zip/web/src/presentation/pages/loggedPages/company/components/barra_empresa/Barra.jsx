import './Barra.css'
export default function Barra(){

    return(
        <>
        <div className="base_barra">
            <div className="barra">
                <nav>
                    <h1>
                        <span>IN</span>teractor 
                    </h1>
                </nav>
            </div>
        </div>
        </>
    )
}