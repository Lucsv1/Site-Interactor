import './perfil.css'
import foto from './img/pasta.png'
import './perfil.css'

export default function Perfil(){

    return(
        <>
        <div className="perfil_base">
            <div className="perfil">
                <img src={foto} alt="fotoEmpresa" />
                <h3>Empresa</h3>
                <h5>Analise Group</h5>
            </div>
        </div>
        </>
    )
}