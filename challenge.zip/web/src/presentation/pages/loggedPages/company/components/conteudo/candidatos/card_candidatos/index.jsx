import './index.css'
import Pessoa from '../img/estagiario.jpg'
export const CardC =() =>{

    return(
        <div className="card_candidatos_base">
            <div className="card_candidatos">
                <h5>Lucas Sartori</h5>
                <img src={Pessoa} alt="imagem de lucas" />
                <div className="info_base">
                    <div className="info">
                        <p>Cursando ADS-Analise e desenvolvimento de software, tem conhecimento nas linguagens:</p>
                        <ul>
                            <li>HTML</li>
                            <li>CSS</li>
                            <li>JavaScript</li>
                            <li>Python</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    )
}