import { CardC } from './card_candidatos'
import './index.css'
export const Candidatos = () =>{

    return(

        <div className="candidatos_base">
            <div className="candidatos">
                <h3>Candidatos</h3>
                <CardC/>

            </div>
        </div>

    )
}