import { CardV } from './card_vagas/Card'
import './index.css'
export const Vagas = () =>{

    return(
        <div className="vagas_base">
            <div className="vagas">
                <h3>Vagas</h3> 
                <CardV/> 
                <button onClick={() => alert("Em desenvolvimento")}>Criar vaga</button>
            </div>
        </div>


    )
}