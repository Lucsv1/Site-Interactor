import'./index.css'
export const CardV =() =>{

    return(
        <>
        <div className="card_vagas_base">
            <div className="card_vagas">
                <h5>Vagas para front-end</h5>
                <p>São mais de Mil candidatos!!!</p>
            </div>
        </div>
        <div className="card_vagas_base2">
            <div className="card_vagas2">
                <h5>Vagas</h5>
            </div>
        </div>
        </>
    )
}