import  "./components/Css/geral.css";
import "./components/barra_empresa/Barra";
import Perfil from "./components/pefil_empresa/Perfil";
import { Conteudo } from "./components/conteudo/index.jsx";
import { Link } from "react-router-dom";

export default function Company() {
  return (
    <div className="companyPage">
      <div className="topbar white">
        <nav>
          <div className="company">
            <h1>
              <span>IN</span>teractor
            </h1>
          </div>
          <ul>
            <li>
              <Link
                to={"/company/dashboard"}
                style={{ color: "inherit", textDecoration: "inherit" }}
              >
                Dashboard
              </Link>
            </li>
          </ul>
        </nav>
      </div>
      <Perfil />
      <Conteudo />
    </div>
  );
}
