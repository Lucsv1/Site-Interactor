import "./style.css";
import { UserCard, DarkCard } from "./components";
import estagiarioImage from "../../../../images/estagiario.jpg";
import ibmImage from "../../../../images/ibm.png";
import { Link } from "react-router-dom";
export const Dashboard = () => {
  return (
    <div className="portal">
      <div className="topbar white">
        <nav>
          <div className="company">
            <h1>
              <span>IN</span>teractor
            </h1>
          </div>
          <ul>
            <li>
              <Link
                to={"/portal/curriculo"}
                style={{ color: "inherit", textDecoration: "inherit" }}
              >
                Gerar curriculo
              </Link>
            </li>
            <li>
              <Link
                to={"/portal/dashboard"}
                style={{ color: "inherit", textDecoration: "inherit" }}
              >
                Dashboard
              </Link>
            </li>
          </ul>
        </nav>
      </div>
      <div className="userInfo">
        <UserCard>
          <img src={estagiarioImage} alt='avatar'></img>
          <h3>Lucas Sartori</h3>
          <h5>ADS - Noturno</h5>
          <br></br>
        </UserCard>
      </div>
      <div className="dashboard">
        <p>Propostas</p>
        <div className="menu">
          <DarkCard>
            <img src={ibmImage} alt='empresa  '></img>
            <p>Ver detalhes</p>
          </DarkCard>
          <DarkCard>
            <img src={ibmImage} alt='empresa'></img>
            <p>Ver detalhes</p>
          </DarkCard>
          <DarkCard>
            <img src={ibmImage} alt='empresa'></img>
            <p>Ver detalhes</p>
          </DarkCard>
          <DarkCard>
            <img src={ibmImage} alt='empresa'></img>
            <p>Ver detalhes</p>
          </DarkCard>
        </div>
      </div>
    </div>
  );
};
