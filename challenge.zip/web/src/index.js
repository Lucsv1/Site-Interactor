import React from "react";
import ReactDOM from "react-dom/client";
import { Login, Home, Register } from "./presentation/pages/unloggedPages";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./index.css";
import { Dashboard, Curriculo } from "./presentation/pages/loggedPages/";
import Company from "./presentation/pages/loggedPages/company/index";
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/login" element={<Login />}></Route>
        <Route path="/register" element={<Register />}></Route>
        <Route path="/portal/dashboard" element={<Dashboard />}></Route>
        <Route path="/portal/curriculo" element={<Curriculo />}></Route>
        <Route path="/company/dashboard" element={<Company />}></Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
